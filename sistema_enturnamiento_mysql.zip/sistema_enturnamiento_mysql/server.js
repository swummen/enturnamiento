// server.js - VERSIÓN COMPLETA CON MYSQL (RAILWAY) Y CAPAS

const express = require('express');
require('dotenv').config();

const { pool, query, healthCheck } = require('./config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = 'sistema_enturnamiento_secret_2024';

// ===============================
// MIDDLEWARES
// ===============================
app.use(express.json());
app.use(express.static('.')); // sirve tus HTML/CSS/JS desde la carpeta del proyecto

// CORS para desarrollo
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// Autenticación JWT
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Token requerido' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, message: 'Token inválido' });
    }
    req.user = user;
    next();
  });
};

// ===============================
// ENDPOINTS DE AUTENTICACIÓN
// ===============================

// Login
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    const users = await query(
      'SELECT * FROM users WHERE username = ? AND estado = "activo"',
      [username]
    );

    if (users.length === 0) {
      return res.status(401).json({ success: false, message: 'Usuario no encontrado' });
    }

    const user = users[0];

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) {
      return res.status(401).json({ success: false, message: 'Contraseña incorrecta' });
    }

    const token = jwt.sign(
      {
        id: user.id,
        username: user.username,
        role: user.role,
        nombre: user.nombre,
      },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    const { password: _, ...userWithoutPassword } = user;

    res.json({
      success: true,
      user: userWithoutPassword,
      token,
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Error del servidor' });
  }
});

// Registro
app.post('/api/register', async (req, res) => {
  try {
    const { username, password, role, nombre, email, telefono } = req.body;

    const rolesPermitidos = ['conductor', 'despachador'];
    if (!rolesPermitidos.includes(role)) {
      return res.status(400).json({ success: false, message: 'Rol no permitido' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const [result] = await pool.execute(
      `INSERT INTO users (username, password, role, nombre, email, telefono) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [username, hashedPassword, role, nombre, email, telefono]
    );

    res.json({
      success: true,
      message: 'Usuario registrado exitosamente',
      userId: result.insertId,
    });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ success: false, message: 'El usuario ya existe' });
    }
    console.error('Register error:', error);
    res.status(500).json({ success: false, message: 'Error al registrar usuario' });
  }
});

// ===============================
// ENDPOINTS DE VEHÍCULOS
// ===============================

// Obtener vehículos
app.get('/api/vehicles', authenticateToken, async (req, res) => {
  try {
    const { estado, ciudad, tipo_vehiculo, tipo_carroceria } = req.query;

    let sql = `
      SELECT v.*, u.nombre AS conductor_nombre, u.telefono AS conductor_telefono
      FROM vehicles v
      JOIN users u ON v.conductor_id = u.id
      WHERE 1=1
    `;
    const params = [];

    if (estado) {
      sql += ' AND v.estado = ?';
      params.push(estado);
    }
    if (ciudad) {
      sql += ' AND v.ciudad_origen = ?';
      params.push(ciudad);
    }
    if (tipo_vehiculo) {
      sql += ' AND v.tipo_vehiculo = ?';
      params.push(tipo_vehiculo);
    }
    if (tipo_carroceria) {
      sql += ' AND v.tipo_carroceria = ?';
      params.push(tipo_carroceria);
    }

    sql += ' ORDER BY v.fecha_actualizacion DESC';

    const vehicles = await query(sql, params);
    res.json({ success: true, vehicles });
  } catch (error) {
    console.error('Get vehicles error:', error);
    res.status(500).json({ success: false, message: 'Error al obtener vehículos' });
  }
});

// Registrar vehículo
app.post('/api/vehicles', authenticateToken, async (req, res) => {
  try {
    const { placa, tipo_vehiculo, tipo_carroceria, ciudad_origen, destino_preferente } = req.body;
    const conductor_id = req.user.id;

    const [result] = await pool.execute(
      `INSERT INTO vehicles 
        (placa, tipo_vehiculo, tipo_carroceria, ciudad_origen, destino_preferente, conductor_id, estado) 
       VALUES (?, ?, ?, ?, ?, ?, 'Disponible')`,
      [placa, tipo_vehiculo, tipo_carroceria, ciudad_origen, destino_preferente, conductor_id]
    );

    res.json({
      success: true,
      message: 'Vehículo registrado correctamente',
      vehicleId: result.insertId,
    });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ success: false, message: 'La placa ya está registrada' });
    }
    console.error('Register vehicle error:', error);
    res.status(500).json({ success: false, message: 'Error al registrar vehículo' });
  }
});

// Actualizar estado de vehículo
app.put('/api/vehicles/:id/status', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const estadosPermitidos = ['Disponible', 'En viaje', 'Mantenimiento'];
    if (!estadosPermitidos.includes(status)) {
      return res.status(400).json({ success: false, message: 'Estado no válido' });
    }

    const [result] = await pool.execute(
      'UPDATE vehicles SET estado = ?, fecha_actualizacion = CURRENT_TIMESTAMP WHERE id = ?',
      [status, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Vehículo no encontrado' });
    }

    res.json({ success: true, message: 'Estado actualizado correctamente' });
  } catch (error) {
    console.error('Update vehicle status error:', error);
    res.status(500).json({ success: false, message: 'Error al actualizar estado' });
  }
});

// Actualizar ubicación GPS
app.put('/api/vehicles/:id/location', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { lat, lng } = req.body;

    const ubicacion = `${lat},${lng}`;

    const [result] = await pool.execute(
      `UPDATE vehicles 
       SET ubicacion_gps = ?, fecha_actualizacion = CURRENT_TIMESTAMP 
       WHERE id = ? AND conductor_id = ?`,
      [ubicacion, id, req.user.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Vehículo no encontrado' });
    }

    res.json({ success: true, message: 'Ubicación actualizada correctamente' });
  } catch (error) {
    console.error('Update location error:', error);
    res.status(500).json({ success: false, message: 'Error al actualizar ubicación' });
  }
});

// ===============================
// ENDPOINTS DE VIAJES
// ===============================

// Obtener viajes
app.get('/api/trips', authenticateToken, async (req, res) => {
  try {
    const { estado } = req.query;
    const user = req.user;

    let sql = `
      SELECT t.*, v.placa, v.tipo_vehiculo,
             u1.nombre AS conductor_nombre,
             u2.nombre AS despachador_nombre
      FROM trips t
      JOIN vehicles v ON t.vehicle_id = v.id
      JOIN users u1 ON v.conductor_id = u1.id
      JOIN users u2 ON t.despachador_id = u2.id
      WHERE 1=1
    `;
    const params = [];

    if (estado) {
      sql += ' AND t.estado = ?';
      params.push(estado);
    }

    if (user.role === 'conductor') {
      sql += ' AND v.conductor_id = ?';
      params.push(user.id);
    } else if (user.role === 'despachador') {
      sql += ' AND t.despachador_id = ?';
      params.push(user.id);
    }

    sql += ' ORDER BY t.fecha_inicio DESC';

    const trips = await query(sql, params);
    res.json({ success: true, trips });
  } catch (error) {
    console.error('Get trips error:', error);
    res.status(500).json({ success: false, message: 'Error al obtener viajes' });
  }
});

// Crear nuevo viaje
app.post('/api/trips', authenticateToken, async (req, res) => {
  try {
    const { vehicle_id, origen, destino, carga, distancia_km, tiempo_estimado_horas } = req.body;
    const despachador_id = req.user.id;

    if (req.user.role !== 'despachador') {
      return res.status(403).json({ success: false, message: 'Solo los despachadores pueden crear viajes' });
    }

    const vehicles = await query('SELECT estado FROM vehicles WHERE id = ?', [vehicle_id]);
    const vehicle = vehicles[0];
    if (!vehicle) {
      return res.status(404).json({ success: false, message: 'Vehículo no encontrado' });
    }
    if (vehicle.estado !== 'Disponible') {
      return res.status(400).json({ success: false, message: 'El vehículo no está disponible' });
    }

    const [tripResult] = await pool.execute(
      `INSERT INTO trips 
        (vehicle_id, despachador_id, origen, destino, carga, distancia_km, tiempo_estimado_horas) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [vehicle_id, despachador_id, origen, destino, carga, distancia_km, tiempo_estimado_horas]
    );

    await pool.execute('UPDATE vehicles SET estado = "En viaje" WHERE id = ?', [vehicle_id]);

    res.json({
      success: true,
      message: 'Viaje creado correctamente',
      tripId: tripResult.insertId,
    });
  } catch (error) {
    console.error('Create trip error:', error);
    res.status(500).json({ success: false, message: 'Error al crear viaje' });
  }
});

// Finalizar viaje
app.put('/api/trips/:id/finalize', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const trips = await query('SELECT vehicle_id FROM trips WHERE id = ?', [id]);
    const trip = trips[0];

    if (!trip) {
      return res.status(404).json({ success: false, message: 'Viaje no encontrado' });
    }

    await pool.execute(
      `UPDATE trips 
       SET estado = "Finalizado", fecha_fin = CURRENT_TIMESTAMP 
       WHERE id = ?`,
      [id]
    );

    await pool.execute(
      'UPDATE vehicles SET estado = "Disponible" WHERE id = ?',
      [trip.vehicle_id]
    );

    res.json({ success: true, message: 'Viaje finalizado correctamente' });
  } catch (error) {
    console.error('Finalize trip error:', error);
    res.status(500).json({ success: false, message: 'Error al finalizar viaje' });
  }
});

// ===============================
// ENDPOINTS DE USUARIOS
// ===============================

// Obtener usuarios (solo admin)
app.get('/api/users', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'administrador') {
      return res.status(403).json({ success: false, message: 'Acceso no autorizado' });
    }

    const { role, estado } = req.query;

    let sql =
      'SELECT id, username, role, nombre, email, telefono, estado, fecha_registro FROM users WHERE 1=1';
    const params = [];

    if (role) {
      sql += ' AND role = ?';
      params.push(role);
    }
    if (estado) {
      sql += ' AND estado = ?';
      params.push(estado);
    }

    sql += ' ORDER BY fecha_registro DESC';

    const users = await query(sql, params);
    res.json({ success: true, users });
  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({ success: false, message: 'Error al obtener usuarios' });
  }
});

// Actualizar rol de usuario
app.put('/api/users/:id/role', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'administrador') {
      return res.status(403).json({ success: false, message: 'Acceso no autorizado' });
    }

    const { id } = req.params;
    const { role } = req.body;

    const rolesPermitidos = ['conductor', 'despachador', 'administrador'];
    if (!rolesPermitidos.includes(role)) {
      return res.status(400).json({ success: false, message: 'Rol no válido' });
    }

    const [result] = await pool.execute('UPDATE users SET role = ? WHERE id = ?', [role, id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Usuario no encontrado' });
    }

    res.json({ success: true, message: 'Rol actualizado correctamente' });
  } catch (error) {
    console.error('Update user role error:', error);
    res.status(500).json({ success: false, message: 'Error al actualizar rol' });
  }
});

// Perfil del usuario actual
app.get('/api/users/me', authenticateToken, async (req, res) => {
  try {
    const users = await query(
      'SELECT id, username, role, nombre, email, telefono, estado FROM users WHERE id = ?',
      [req.user.id]
    );
    const user = users[0];

    if (!user) {
      return res.status(404).json({ success: false, message: 'Usuario no encontrado' });
    }

    res.json({ success: true, user });
  } catch (error) {
    console.error('Get user profile error:', error);
    res.status(500).json({ success: false, message: 'Error al obtener perfil' });
  }
});

// ===============================
// CIUDADES / RUTAS
// ===============================

// Obtener ciudades
app.get('/api/cities', authenticateToken, async (req, res) => {
  try {
    const { estado } = req.query;

    let sql = 'SELECT * FROM cities WHERE 1=1';
    const params = [];

    if (estado) {
      sql += ' AND estado = ?';
      params.push(estado);
    }

    sql += ' ORDER BY nombre';

    const cities = await query(sql, params);
    res.json({ success: true, cities });
  } catch (error) {
    console.error('Get cities error:', error);
    res.status(500).json({ success: false, message: 'Error al obtener ciudades' });
  }
});

// Crear ciudad (solo admin)
app.post('/api/cities', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'administrador') {
      return res.status(403).json({ success: false, message: 'Acceso no autorizado' });
    }

    const { nombre, departamento, codigo } = req.body;

    const [result] = await pool.execute(
      'INSERT INTO cities (nombre, departamento, codigo) VALUES (?, ?, ?)',
      [nombre, departamento, codigo]
    );

    res.json({
      success: true,
      message: 'Ciudad creada correctamente',
      cityId: result.insertId,
    });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ success: false, message: 'El código de ciudad ya existe' });
    }
    console.error('Create city error:', error);
    res.status(500).json({ success: false, message: 'Error al crear ciudad' });
  }
});

// Obtener rutas (requiere tabla routes creada)
app.get('/api/routes', authenticateToken, async (req, res) => {
  try {
    const routes = await query(
      `SELECT r.*, c1.nombre AS origen_nombre, c2.nombre AS destino_nombre
       FROM routes r
       JOIN cities c1 ON r.ciudad_origen_id = c1.id
       JOIN cities c2 ON r.ciudad_destino_id = c2.id
       ORDER BY c1.nombre, c2.nombre`
    );

    res.json({ success: true, routes });
  } catch (error) {
    console.error('Get routes error:', error);
    res.status(500).json({ success: false, message: 'Error al obtener rutas' });
  }
});

// ===============================
// NOTIFICACIONES
// ===============================

app.get('/api/notifications', authenticateToken, async (req, res) => {
  try {
    const { leida } = req.query;

    let sql = 'SELECT * FROM notifications WHERE user_id = ?';
    const params = [req.user.id];

    if (leida !== undefined) {
      sql += ' AND leida = ?';
      params.push(leida === 'true');
    }

    sql += ' ORDER BY fecha_creacion DESC';

    const notifications = await query(sql, params);
    res.json({ success: true, notifications });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ success: false, message: 'Error al obtener notificaciones' });
  }
});

app.put('/api/notifications/:id/read', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await pool.execute(
      'UPDATE notifications SET leida = TRUE WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Notificación no encontrada' });
    }

    res.json({ success: true, message: 'Notificación marcada como leída' });
  } catch (error) {
    console.error('Mark notification read error:', error);
    res.status(500).json({ success: false, message: 'Error al actualizar notificación' });
  }
});

// ===============================
// REPORTES
// ===============================

app.get('/api/reports/availability', authenticateToken, async (req, res) => {
  try {
    const { fecha_inicio, fecha_fin, ciudad } = req.query;

    let sql = `
      SELECT 
        v.ciudad_origen,
        v.tipo_vehiculo,
        COUNT(*) AS total_vehiculos,
        SUM(CASE WHEN v.estado = 'Disponible' THEN 1 ELSE 0 END) AS disponibles,
        SUM(CASE WHEN v.estado = 'En viaje' THEN 1 ELSE 0 END) AS en_viaje
      FROM vehicles v
      WHERE v.fecha_actualizacion BETWEEN ? AND ?
    `;
    const params = [fecha_inicio || '2024-01-01', fecha_fin || '2024-12-31'];

    if (ciudad) {
      sql += ' AND v.ciudad_origen = ?';
      params.push(ciudad);
    }

    sql += ' GROUP BY v.ciudad_origen, v.tipo_vehiculo ORDER BY v.ciudad_origen';

    const report = await query(sql, params);
    res.json({ success: true, report });
  } catch (error) {
    console.error('Availability report error:', error);
    res.status(500).json({ success: false, message: 'Error al generar reporte' });
  }
});

// ===============================
// DIAGNÓSTICO / STATUS
// ===============================

app.get('/api/status', async (req, res) => {
  const ok = await healthCheck();
  if (!ok) {
    return res.status(500).json({
      success: false,
      message: 'Servidor OK, pero la base de datos Railway NO responde',
      timestamp: new Date().toISOString(),
    });
  }
  res.json({
    success: true,
    message: 'Servidor y base de datos Railway OK',
    timestamp: new Date().toISOString(),
  });
});

async function initializeDatabase() {
  try {
    // Tabla de usuarios
    await query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('conductor','despachador','administrador') NOT NULL,
        nombre VARCHAR(100) NOT NULL,
        email VARCHAR(100),
        telefono VARCHAR(30),
        estado ENUM('activo','inactivo') DEFAULT 'activo',
        fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Tabla de vehículos
    await query(`
      CREATE TABLE IF NOT EXISTS vehicles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        placa VARCHAR(20) NOT NULL UNIQUE,
        tipo_vehiculo VARCHAR(50) NOT NULL,
        tipo_carroceria VARCHAR(50) NOT NULL,
        ciudad_origen VARCHAR(100) NOT NULL,
        destino_preferente VARCHAR(100),
        estado ENUM('Disponible','En viaje','Mantenimiento') DEFAULT 'Disponible',
        conductor_id INT NOT NULL,
        ubicacion_gps VARCHAR(100),
        fecha_actualizacion DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Tabla de viajes
    await query(`
      CREATE TABLE IF NOT EXISTS trips (
        id INT AUTO_INCREMENT PRIMARY KEY,
        vehicle_id INT NOT NULL,
        despachador_id INT NOT NULL,
        origen VARCHAR(100) NOT NULL,
        destino VARCHAR(100) NOT NULL,
        carga VARCHAR(255),
        estado ENUM('En curso','Finalizado','Completado') DEFAULT 'En curso',
        fecha_inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
        fecha_fin DATETIME,
        distancia_km DECIMAL(10,2),
        tiempo_estimado_horas DECIMAL(10,2)
      )
    `);

    // Tabla de ciudades
    await query(`
      CREATE TABLE IF NOT EXISTS cities (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
        departamento VARCHAR(100) NOT NULL,
        codigo VARCHAR(20) UNIQUE,
        estado ENUM('activa','inactiva') DEFAULT 'activa'
      )
    `);

    // Tabla de rutas
    await query(`
      CREATE TABLE IF NOT EXISTS routes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ciudad_origen_id INT NOT NULL,
        ciudad_destino_id INT NOT NULL
      )
    `);

    // Tabla de notificaciones
    await query(`
      CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        titulo VARCHAR(100) NOT NULL,
        mensaje TEXT NOT NULL,
        tipo ENUM('info','warning','error') DEFAULT 'info',
        leida BOOLEAN DEFAULT FALSE,
        accion VARCHAR(255),
        fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    console.log('Tablas verificadas/creadas correctamente en Railway');
  } catch (err) {
    console.error('Error creando tablas en Railway:', err);
    throw err;
  }
}

initializeDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Servidor API ejecutándose en http://localhost:${PORT}`);
      console.log(`Base de datos: MySQL en Railway (host: ${process.env.DB_HOST})`);
    });
  })
  .catch((err) => {
    console.error('No se pudo inicializar la base de datos. Cerrando servidor.');
    process.exit(1);
  });