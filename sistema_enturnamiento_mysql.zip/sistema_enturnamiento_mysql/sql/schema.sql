CREATE DATABASE IF NOT EXISTS enturnamiento CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE enturnamiento;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('conductor','despachador','administrador') NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    telefono VARCHAR(30),
    estado ENUM('activo','inactivo') DEFAULT 'activo',
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    placa VARCHAR(20) NOT NULL UNIQUE,
    tipo_vehiculo VARCHAR(50) NOT NULL,
    tipo_carroceria VARCHAR(50) NOT NULL,
    ciudad_origen VARCHAR(100) NOT NULL,
    destino_preferente VARCHAR(100),
    estado ENUM('Disponible','En viaje') DEFAULT 'Disponible',
    conductor_id INT NOT NULL,
    ubicacion_gps VARCHAR(100),
    fecha_actualizacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_vehicles_conductor
        FOREIGN KEY (conductor_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS trips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    despachador_id INT NOT NULL,
    origen VARCHAR(100) NOT NULL,
    destino VARCHAR(100) NOT NULL,
    carga VARCHAR(255),
    estado ENUM('En curso','Finalizado') DEFAULT 'En curso',
    fecha_inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
    fecha_fin DATETIME,
    distancia_km DECIMAL(10,2),
    tiempo_estimado_horas DECIMAL(10,2),
    CONSTRAINT fk_trips_vehicle
        FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
    CONSTRAINT fk_trips_despachador
        FOREIGN KEY (despachador_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS cities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    departamento VARCHAR(100) NOT NULL,
    codigo VARCHAR(20) UNIQUE,
    estado ENUM('activa','inactiva') DEFAULT 'activa'
);

CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    titulo VARCHAR(100) NOT NULL,
    mensaje TEXT NOT NULL,
    tipo ENUM('info','warning','error') DEFAULT 'info',
    leida BOOLEAN DEFAULT FALSE,
    accion VARCHAR(255),
    fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notifications_user
        FOREIGN KEY (user_id) REFERENCES users(id)
);
