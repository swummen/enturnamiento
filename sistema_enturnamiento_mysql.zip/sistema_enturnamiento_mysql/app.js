// app.js - Lógica principal del sistema

// API simple para gestionar datos
const API = {
    baseURL: 'http://localhost:3000/api',
    
    async request(endpoint, options = {}) {
        const token = localStorage.getItem('authToken');
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...(token && { 'Authorization': `Bearer ${token}` }),
                ...options.headers
            },
            ...options
        };
        
        try {
            console.log(`🔄 API Call: ${endpoint}`);
            const response = await fetch(`${this.baseURL}${endpoint}`, config);
            const data = await response.json();
            console.log(`✅ API Response:`, data);
            return data;
        } catch (error) {
            console.error('❌ API Error:', error);
            return { 
                success: false, 
                message: 'Error de conexión con el servidor. Verifica que el servidor esté ejecutándose.' 
            };
        }
    },
    
    // Métodos para vehículos
    async getVehicles(filters = {}) {
        const queryParams = new URLSearchParams(filters).toString();
        return await this.request(`/vehicles?${queryParams}`);
    },
    
    async updateVehicleStatus(vehicleId, status) {
        const response = await fetch(`${this.baseURL}/vehicles/${vehicleId}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status })
        });
        return await response.json();
    }
};

// Sistema de navegación
class NavigationSystem {
    constructor() {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;
        this.init();
    }
    
    init() {
        this.loadHeader();
        this.loadFooter();
        this.setupEventListeners();
    }
    
    loadHeader() {
        const headerContainer = document.getElementById('header-container');
        if (headerContainer) {
            fetch('header.html')
                .then(response => response.text())
                .then(html => {
                    headerContainer.innerHTML = html;
                    this.updateNavigationBasedOnUser();
                })
                .catch(error => {
                    console.error('Error loading header:', error);
                    headerContainer.innerHTML = this.getDefaultHeader();
                });
        }
    }
    
    loadFooter() {
        const footerContainer = document.getElementById('footer-container');
        if (footerContainer) {
            fetch('footer.html')
                .then(response => response.text())
                .then(html => {
                    footerContainer.innerHTML = html;
                })
                .catch(error => {
                    console.error('Error loading footer:', error);
                    footerContainer.innerHTML = this.getDefaultFooter();
                });
        }
    }
    
    getDefaultHeader() {
        return `
            <header class="header">
                <div class="logo">
                    <h2>Sistema Enturnamiento</h2>
                </div>
                <nav class="nav">
                    <a href="index.html">Inicio</a>
                    <a href="inicio_sesion.html">Iniciar Sesión</a>
                    <a href="registration.html">Registrarse</a>
                </nav>
            </header>
        `;
    }
    
    getDefaultFooter() {
        return `
            <footer class="footer">
                <div class="footer-content">
                    <div class="footer-section">
                        <h3>Empresa</h3>
                        <p>Sistema de gestión de enturnamiento para vehículos de terceros</p>
                    </div>
                    <div class="footer-section">
                        <h3>Enlaces rápidos</h3>
                        <ul>
                            <li><a href="#">Contratos</a></li>
                            <li><a href="#">Distribuidores</a></li>
                            <li><a href="#">Nosotros</a></li>
                        </ul>
                    </div>
                    <div class="footer-section">
                        <h3>Contacto</h3>
                        <p>+1 999 9845 556</p>
                        <p>info@empresa.com</p>
                    </div>
                </div>
                <div class="footer-bottom">
                    <p>&copy; 2025 Empresa. Todos los derechos reservados.</p>
                </div>
            </footer>
        `;
    }
    
    updateNavigationBasedOnUser() {
        if (this.currentUser) {
            const nav = document.querySelector('.nav');
            if (nav) {
                // Limpiar navegación
                nav.innerHTML = '';
                
                // Agregar enlaces comunes
                nav.innerHTML += `<a href="index.html">Inicio</a>`;
                
                // Agregar enlaces específicos por rol
                switch(this.currentUser.role) {
                    case 'conductor':
                        nav.innerHTML += `
                            <a href="conductor.html">Panel Conductor</a>
                            <a href="viajes.html">Mis Viajes</a>
                        `;
                        break;
                    case 'despachador':
                        nav.innerHTML += `
                            <a href="despachador.html">Panel Despachador</a>
                            <a href="notificaciones.html">Notificaciones</a>
                        `;
                        break;
                    case 'administrador':
                        nav.innerHTML += `
                            <a href="administrador.html">Panel Admin</a>
                            <a href="ruta.html">Gestión Rutas</a>
                        `;
                        break;
                }
                
                // Agregar usuario y cerrar sesión
                nav.innerHTML += `
                    <span class="user-info">${this.currentUser.username}</span>
                    <a href="#" id="logout-btn">Cerrar Sesión</a>
                `;
                
                // Configurar evento de cierre de sesión
                document.getElementById('logout-btn').addEventListener('click', (e) => {
                    e.preventDefault();
                    this.logout();
                });
            }
        }
    }
    
    setupEventListeners() {
        // Eventos globales
        document.addEventListener('DOMContentLoaded', () => {
            // Verificar si hay una sesión activa
            if (this.currentUser) {
                this.redirectToDashboard();
            }
        });
    }
    
    redirectToDashboard() {
        const currentPage = window.location.pathname.split('/').pop();
        if (currentPage === 'index.html' || currentPage === '') {
            switch(this.currentUser.role) {
                case 'conductor':
                    window.location.href = 'conductor.html';
                    break;
                case 'despachador':
                    window.location.href = 'despachador.html';
                    break;
                case 'administrador':
                    window.location.href = 'administrador.html';
                    break;
            }
        }
    }
    
    async login(credentials) {
        try {
            const result = await API.login(credentials);
            if (result.success) {
                this.currentUser = result.user;
                localStorage.setItem('currentUser', JSON.stringify(result.user));
                this.redirectToDashboard();
                return { success: true };
            } else {
                return { success: false, message: result.message };
            }
        } catch (error) {
            console.error('Login error:', error);
            return { success: false, message: 'Error de conexión' };
        }
    }
    
    logout() {
        this.currentUser = null;
        localStorage.removeItem('currentUser');
        window.location.href = 'index.html';
    }
}

// Inicializar el sistema de navegación
const navigation = new NavigationSystem();

// Funciones globales para usar en otras páginas
window.navigationSystem = navigation;
window.API = API;